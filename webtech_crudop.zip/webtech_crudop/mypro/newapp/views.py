from django.shortcuts import redirect,render
from .models import List


def index(request):
    list = List.objects.all()

    return render(request,'index.html',{'list':list})

def addlist(request):

    return render(request,'addlist.html',{'list':list})

def additem(request):
    x=request.POST['name']
    y=request.POST['category']
    z=request.POST['price']
    list=List(name=x,category=y,price=z)
    list.save()
    return redirect("/")

def delete(request,id):
    list=List.objects.get(id=id)
    list.delete()
    return redirect("/")

def update(request,id):
    list=List.objects.get(id=id)
    return render(request,'updatelist.html',{'list':list})

def upitem(request,id):
    x=request.POST['name']
    y=request.POST['category']
    z=request.POST['price']
    list=List.objects.get(id=id)
    list.name=x
    list.category=y
    list.price=z
    list.save()
    return redirect("/")